import React from 'react';
import { Download, ChevronRight } from 'lucide-react';
import type { DataTableProps } from '../types/satellite';

export function DataTable({ data, onDownload }: DataTableProps) {
  const formatSampleData = (value: any) => {
    if (Array.isArray(value)) {
      if (value.length === 0) return 'Empty array';
      const sample = JSON.stringify(value[0]);
      return sample.length > 50 ? `${sample.slice(0, 47)}...` : sample;
    }
    return 'Invalid data format';
  };

  return (
    <div className="bg-blue-900/20 rounded-lg p-6 backdrop-blur-sm">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold">Satellite Data Overview</h2>
        <button
          onClick={onDownload}
          className="flex items-center gap-2 px-4 py-2 bg-blue-500 rounded-lg hover:bg-blue-600 transition-colors"
        >
          <Download className="w-4 h-4" />
          Export CSV
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-blue-400/30">
              <th className="text-left py-3 px-4">Category</th>
              <th className="text-left py-3 px-4">Count</th>
              <th className="text-left py-3 px-4">Sample Data</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(data).map(([key, value]) => (
              <tr 
                key={key} 
                className="border-b border-blue-400/10 hover:bg-blue-900/30 cursor-pointer group"
              >
                <td className="py-3 px-4 font-medium flex items-center gap-2">
                  <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                  {key}
                </td>
                <td className="py-3 px-4">{Array.isArray(value) ? value.length : 0}</td>
                <td className="py-3 px-4 font-mono text-xs">
                  {formatSampleData(value)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}